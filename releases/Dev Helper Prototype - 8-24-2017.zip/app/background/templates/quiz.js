
function quiz(info) {
  let template = require('./quiz.xml');

  console.log(template);
}

module.exports = quiz;
