let path = require('path');

module.exports = {
  image : require('../image/middleware.js')
};
