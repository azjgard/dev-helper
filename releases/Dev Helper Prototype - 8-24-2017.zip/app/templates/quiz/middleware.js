module.exports = function($template, meta) {

  $template.setTxt ('QuestionList', 'Here is a question fro you...');

  $template.finish();
};
