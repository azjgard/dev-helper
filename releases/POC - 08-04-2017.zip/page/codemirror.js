console.log('gnksdfngksdjf');
var myCodeMirror = CodeMirror(document.body);

console.log(CodeMirror);
