module.exports = {
  slideType : require('./slideType.html'),
  slides    : {
    image : require('./image/image.html')
  }
};
