function exam(info) {
  let template = require('./exam.xml');

  console.log(template);
}

module.exports = exam;
